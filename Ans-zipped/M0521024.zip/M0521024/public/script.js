const div = document.querySelector("div");
div.textContent = "Halo";