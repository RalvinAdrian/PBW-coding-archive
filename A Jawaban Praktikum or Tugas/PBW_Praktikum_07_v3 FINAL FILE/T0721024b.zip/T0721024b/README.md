# Project Tugas 07b

Author: Ralvin Adrian  
NPM: 6182101024  
Version: 0.0.5

## Updates

### 0.0.5

- Finished login verification in '/login' route and bypass initial login to use same credential : 'password'

### 0.0.4

- Update login & sign out button conditioned by user session status

### 0.0.3

- Updated routing to show a maximum of 8 rows of SQL table data, indexed through all users rows.

### 0.0.2

- Finalized the update username menu and other related changes.

### 0.0.1

- Updated the addRole menu.

Made for github archiving only, mohon abaikan apabila file ikut tercantumkan
