/*
[Catatan Penggunaan Template]
- implementasi sesuai apa yang diminta.
- tidak mengubah flow kode pada bagian IIFE.
- tidak mengubah method signature dan parameter.
- selain data inisialisasi, tidak ada kode HARDCODE.
*/

/*
Kelas Rider di sini
mempunyai constructor dengan parameter sesuai
mempunyai method toString yg mengembalikan
  string sesuai keluaran dengan memanfaatkan string templating
*/

class Prix{
	//constructor dengan parameter name

	//memasukkan SATU buah rider ke dalam array of Rider
	addRider(rider){
		
	}

	//mengembalikan array of Rider 
	showRiders(){
		
	}

	//buat implementasi insertion sort dalam bahasa js
	//sort berdasarkan nomor motor
	sortA(){
		
	}

	//Challenge : buat sort dengan memanfaatkan array.sort
	//sort berdasarkan nomor motor
	//jika mengerjakan ini, bukan berarti method sortA tidak dibuat
	sortB(){
		
	}

	showSortedRiders(){
		return this.sortA();
		// return this.sortB();
	}

	//melakukan pengolahan data sehingga dimunculkan output sesuai
	//dengan instruksi pada soal
	//BUKAN DI HARDCODE!!
	//hint: manfaatkan kemampuan dynamic type dari js
	showByBike(){
		
	}

	//melakukan random antara index dari array
	//mengembalikan rider pada index sesuai random
	pickWinner(){
		
	}
}

/*
buat fungsi initPrix di sini.
-inisialisasi variable riders sesuai dengan di soal
-inisialisasi prix dengan nama "mandalika"
-masukkan semua rider ke dalam prix
-mengembalikan referensi prix
*/

(function (){
	const mandalika = initPrix();
	console.log("[Rider] " + mandalika.showRiders());
	console.log("[Sorted] " + mandalika.showSortedRiders());
	console.log("[By Bike]\n" + mandalika.showByBike());
	console.log("[Winner] " + mandalika.pickWinner());
})();

/*
jelaskan penggunaan Immediately Invoked Function Expression (IIFE) di sini:
	
*/