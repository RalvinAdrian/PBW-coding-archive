const dumbFunction = async (name) => {
	return Math.random() < 0.1 ? name : Promise.reject(false);
}

//TODO: fungsi retryUntilSucceed HERE

//TODO: fungsi retryNTimes HERE

(async () => {
	console.log(await retryUntilSucceed(dumbFunction))
	console.log(await retryNTimes(dumbFunction,3,1000))
})();