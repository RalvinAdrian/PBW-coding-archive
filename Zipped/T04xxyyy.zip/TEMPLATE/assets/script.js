//nomor 5
function checkMin8Char(event){
	
}

//nomor 6
function initDoB(day_el,month_el,year_el){
	const months= ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	
}

//nomor 9
function validation(event){
	
}

//nomor 11
function submit(event){
	
}

(function(){
	//nomor 3: mouse hover
	
	//nomor6: dob
	
	//event listener check input, button, submit
	
})();
	
